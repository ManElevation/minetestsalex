# colour_chat
A minetest CSM mod for changing the colour of text sent to the server.

### Usage
Use .set_colour to set the colour of chat sent to the server, you can use either HTML named colours or HTML hexdecimal colour codes. Use .rainbow to generate rainbow text
